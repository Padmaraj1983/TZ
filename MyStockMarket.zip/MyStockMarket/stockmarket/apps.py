from django.apps import AppConfig


class StockmarketConfig(AppConfig):
    name = 'stockmarket'
